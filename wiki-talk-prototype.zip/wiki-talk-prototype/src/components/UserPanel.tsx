import { useState } from 'react'
import type { UserProfile } from '../types'

interface Props {
  user: string
  profile: UserProfile | null // null = no JSON file for this user yet
}

/**
 * Right-hand panel for the selected user.
 * Only the two section shells from the reference screenshot are built so far;
 * their contents are intentionally empty until the scraper's JSON schema and
 * the per-card specs are provided.
 */
export default function UserPanel({ user, profile }: Props) {
  return (
    <div className="user-panel">
      <Section title={`${user}'s account information`} defaultOpen>
        {profile ? null : <p className="panel-note">No profile file found for {user}.</p>}
      </Section>
      <Section title={`${user}'s social network`} defaultOpen={false}>
        {null}
      </Section>
    </div>
  )
}

function Section({
  title,
  defaultOpen,
  children,
}: {
  title: string
  defaultOpen: boolean
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <section className="panel-section">
      <button className="panel-toggle" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <span className={'caret' + (open ? ' open' : '')} aria-hidden="true" />
      </button>
      <h2 className="panel-title">{title}</h2>
      {open && <div className="panel-body">{children}</div>}
    </section>
  )
}
